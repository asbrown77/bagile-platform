﻿using Bagile.EtlService.Models;
using Microsoft.Extensions.Logging;

namespace Bagile.EtlService.Services
{
    public class XeroInvoiceService : IProcessor<CanonicalXeroInvoiceDto>
    {
        private readonly ILogger<XeroInvoiceService> _logger;

        public XeroInvoiceService(ILogger<XeroInvoiceService> logger)
        {
            _logger = logger;
        }

        public Task ProcessAsync(CanonicalXeroInvoiceDto dto, CancellationToken token)
        {
            _logger.LogInformation(
                "Processed Xero invoice {InvoiceNumber} ({Status}) Total {Total} {Currency} Contact {ContactName}",
                dto.InvoiceNumber,
                dto.Status,
                dto.Total,
                dto.Currency,
                dto.ContactName);

            // Later:
            // - Upsert Order
            // - Upsert Company (ContactCompany)
            // - Upsert Student(s)
            // - Upsert Enrolments for each course line
            // - Link payments + credits

            return Task.CompletedTask;
        }
    }
}