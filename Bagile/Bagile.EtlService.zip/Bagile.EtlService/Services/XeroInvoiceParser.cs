﻿using System.Text.Json;
using Bagile.Domain.Entities;
using Bagile.EtlService.Models;

namespace Bagile.EtlService.Services
{
    public class XeroInvoiceParser : IParser<CanonicalXeroInvoiceDto>
    {
        public Task<CanonicalXeroInvoiceDto> Parse(RawOrder raw)
        {
            using var doc = JsonDocument.Parse(raw.Payload);
            var root = doc.RootElement;

            var dto = new CanonicalXeroInvoiceDto
            {
                RawOrderId = raw.Id,
                RawPayload = raw.Payload,

                // Basic fields
                InvoiceId = TryString(root, "InvoiceID"),
                InvoiceNumber = TryString(root, "InvoiceNumber"),
                Reference = TryString(root, "Reference"),
                Status = TryString(root, "Status"),

                // Financials
                Total = TryDecimal(root, "Total"),
                AmountDue = TryDecimal(root, "AmountDue"),
                AmountPaid = TryDecimal(root, "AmountPaid"),
                AmountCredited = TryDecimal(root, "AmountCredited"),
                Currency = TryString(root, "CurrencyCode") ?? "GBP",

                // Customer fields
                ContactName = TryGetContactName(root),
                ContactEmail = TryGetContactEmail(root),
                ContactCompany = TryGetContactCompany(root),

                LineItems = ParseLineItems(root)
            };

            return Task.FromResult(dto);
        }

        // ------------------------------------------------------------
        // LINE ITEMS
        // ------------------------------------------------------------
        private List<CanonicalXeroLineItemDto> ParseLineItems(JsonElement root)
        {
            var result = new List<CanonicalXeroLineItemDto>();

            if (!root.TryGetProperty("LineItems", out var items) ||
                items.ValueKind != JsonValueKind.Array)
            {
                return result;
            }

            foreach (var li in items.EnumerateArray())
            {
                result.Add(new CanonicalXeroLineItemDto
                {
                    Sku = TryString(li, "ItemCode"),
                    Description = TryString(li, "Description") ?? "",
                    Quantity = TryInt(li, "Quantity"),
                    UnitAmount = TryDecimal(li, "UnitAmount"),
                    LineAmount = TryDecimal(li, "LineAmount")
                });
            }

            return result;
        }

        // ------------------------------------------------------------
        // CONTACT FIELDS
        // ------------------------------------------------------------
        private string TryGetContactName(JsonElement root)
        {
            if (!root.TryGetProperty("Contact", out var contact))
                return "";

            return TryString(contact, "Name") ?? "";
        }

        private string TryGetContactEmail(JsonElement root)
        {
            if (!root.TryGetProperty("Contact", out var contact))
                return "";

            return TryString(contact, "EmailAddress") ?? "";
        }

        private string TryGetContactCompany(JsonElement root)
        {
            if (!root.TryGetProperty("Contact", out var contact))
                return "";

            return TryString(contact, "Name") ?? "";
        }

        // ------------------------------------------------------------
        // SAFE READ HELPERS
        // ------------------------------------------------------------
        private string? TryString(JsonElement element, string name)
        {
            if (element.TryGetProperty(name, out var prop) &&
                prop.ValueKind == JsonValueKind.String)
            {
                return prop.GetString();
            }

            return null;
        }

        private decimal TryDecimal(JsonElement element, string name)
        {
            if (element.TryGetProperty(name, out var prop))
            {
                if (prop.ValueKind == JsonValueKind.Number &&
                    prop.TryGetDecimal(out var d))
                {
                    return d;
                }

                if (prop.ValueKind == JsonValueKind.String &&
                    decimal.TryParse(prop.GetString(), out d))
                {
                    return d;
                }
            }

            return 0m;
        }

        private int TryInt(JsonElement element, string name)
        {
            if (element.TryGetProperty(name, out var prop) &&
                prop.TryGetInt32(out var i))
            {
                return i;
            }

            return 0;
        }
    }
}
