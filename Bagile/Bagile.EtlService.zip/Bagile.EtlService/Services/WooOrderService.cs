﻿using System.Linq;
using System.Text.Json;
using Bagile.Domain.Entities;
using Bagile.Domain.Repositories;
using Bagile.EtlService.Models;
using Microsoft.Extensions.Logging;

namespace Bagile.EtlService.Services
{
    public class WooOrderService : IProcessor<CanonicalWooOrderDto>
    {
        private readonly IStudentRepository _studentRepo;
        private readonly IEnrolmentRepository _enrolmentRepo;
        private readonly ICourseScheduleRepository _courseRepo;
        private readonly IOrderRepository _orderRepo;
        private readonly ILogger<WooOrderService> _logger;

        public WooOrderService(
            IStudentRepository studentRepo,
            IEnrolmentRepository enrolmentRepo,
            ICourseScheduleRepository courseRepo,
            IOrderRepository orderRepo,
            ILogger<WooOrderService> logger)
        {
            _studentRepo = studentRepo;
            _enrolmentRepo = enrolmentRepo;
            _courseRepo = courseRepo;
            _orderRepo = orderRepo;
            _logger = logger;
        }

        public async Task ProcessAsync(CanonicalWooOrderDto dto, CancellationToken token)
        {
            // ------------------------------------------------------------
            // Create or update order
            // ------------------------------------------------------------
            if (dto.OrderId == 0)
            {
                var order = new Order
                {
                    RawOrderId = dto.RawOrderId,
                    ExternalId = dto.ExternalId,
                    Source = "woo",
                    Type = "public",
                    Reference = dto.ExternalId,

                    BillingCompany = dto.BillingCompany,
                    ContactName = dto.BillingName,
                    ContactEmail = dto.BillingEmail,

                    TotalQuantity = dto.TotalQuantity,
                    SubTotal = dto.SubTotal,
                    TotalTax = dto.TotalTax,
                    TotalAmount = dto.Total,

                    PaymentTotal = dto.PaymentTotal,
                    RefundTotal = dto.RefundTotal,
                    NetTotal = dto.PaymentTotal - dto.RefundTotal,

                    Status = dto.Status,
                    LifecycleStatus = MapLifecycleStatus(dto.Status, dto.PaymentTotal, dto.RefundTotal),
                    Currency = dto.Currency,
                    OrderDate = DateTime.UtcNow
                };

                dto.OrderId = await _orderRepo.UpsertOrderAsync(order);
            }

            // ------------------------------------------------------------
            // Ensure student exists, prefer attendee details over billing
            // ------------------------------------------------------------
            Student student;

            var primaryTicket = dto.Tickets.FirstOrDefault();

            if (primaryTicket != null &&
                !string.IsNullOrWhiteSpace(primaryTicket.Email))
            {
                student = new Student
                {
                    Email = primaryTicket.Email.ToLowerInvariant(),
                    FirstName = primaryTicket.FirstName,
                    LastName = primaryTicket.LastName,
                    Company = string.IsNullOrWhiteSpace(primaryTicket.Company)
                        ? dto.BillingCompany
                        : primaryTicket.Company
                };
            }
            else
            {
                // fallback to billing details if no attendee info present
                student = new Student
                {
                    Email = dto.BillingEmail?.ToLowerInvariant() ?? string.Empty,
                    FirstName = ExtractFirst(dto.BillingName),
                    LastName = ExtractLast(dto.BillingName),
                    Company = dto.BillingCompany
                };
            }

            var studentId = await _studentRepo.UpsertAsync(student);

            // ------------------------------------------------------------
            // INTERNAL TRANSFER — improved detection
            // ------------------------------------------------------------
            bool shouldTryTransfer = false;

            // Rule 1: No FooEvents metadata → likely admin transfer
            if (!dto.HasFooEventsMetadata)
            {
                shouldTryTransfer = true;
            }

            // Rule 2: Billing company indicates an internal manual transfer
            if (!shouldTryTransfer &&
                dto.BillingCompany != null &&
                dto.BillingCompany.Trim().ToLower() is "b-agile" or "bagile" or "bagile limited")
            {
                shouldTryTransfer = true;
            }

            // Rule 3: Student has prior enrolments in this course family → likely transfer
            if (!shouldTryTransfer && dto.Tickets.Count > 0)
            {
                var prefix = ExtractCoursePrefix(dto.Tickets[0].Sku);
                if (!string.IsNullOrWhiteSpace(prefix))
                {
                    var old = await _enrolmentRepo.FindHeuristicTransferSourceAsync(studentId, prefix);
                    if (old != null)
                    {
                        shouldTryTransfer = true;
                    }
                }
            }

            if (shouldTryTransfer)
            {
                var handled = await TryHandleInternalTransferAsync(dto, studentId, token);

                if (handled)
                {
                    _logger.LogInformation(
                        "Internal transfer for order {OrderId} completed successfully. Skipping normal enrolment creation.",
                        dto.OrderId);
                    return;
                }

                _logger.LogWarning(
                    "Internal transfer candidate for order {OrderId} but no suitable previous enrolment found. Falling back to normal enrolment.",
                    dto.OrderId);
            }


            // ------------------------------------------------------------
            // CANCELLATION or FULL REFUND
            // ------------------------------------------------------------
            if (dto.Status == "cancelled" ||
                (dto.RefundTotal > 0 && dto.RefundTotal >= dto.PaymentTotal))
            {
                await HandleFullCancellationAsync(dto.OrderId);
                return;
            }

            // ------------------------------------------------------------
            // BILLING ONLY
            // ------------------------------------------------------------
            if (dto.Tickets.Count == 0)
            {
                await CreateBillingOnlyEnrolmentAsync(dto, studentId, token);
                return;
            }

            // ------------------------------------------------------------
            // NORMAL ENROLMENTS
            // ------------------------------------------------------------
            foreach (var ticket in dto.Tickets)
            {
                var schedule = await ResolveScheduleAsync(ticket);

                var enrolment = new Enrolment
                {
                    StudentId = studentId,
                    OrderId = dto.OrderId,
                    CourseScheduleId = schedule.Id,
                    Status = "active"
                };

                await _enrolmentRepo.UpsertAsync(enrolment);
            }
        }

        // ================================================================
        // INTERNAL TRANSFER HANDLING
        // ================================================================
        private async Task<bool> TryHandleInternalTransferAsync(
            CanonicalWooOrderDto dto,
            long studentId,
            CancellationToken token)
        {
            if (dto.Tickets.Count == 0)
            {
                return false;
            }

            bool didAtLeastOneTransfer = false;

            foreach (var ticket in dto.Tickets)
            {
                var schedule = await ResolveScheduleAsync(ticket);
                if (schedule == null)
                {
                    _logger.LogWarning(
                        "Internal transfer ticket for order {OrderId} could not resolve schedule for SKU {Sku} ProductId {ProductId}.",
                        dto.ExternalId, ticket.Sku, ticket.ProductId);
                    continue;
                }

                var prefix = ExtractCoursePrefix(ticket.Sku);
                if (string.IsNullOrWhiteSpace(prefix))
                {
                    _logger.LogWarning(
                        "Internal transfer ticket for order {OrderId} has no SKU prefix, SKU={Sku}.",
                        dto.ExternalId, ticket.Sku);
                    continue;
                }

                var oldEnrol = await _enrolmentRepo.FindHeuristicTransferSourceAsync(studentId, prefix);
                if (oldEnrol == null)
                {
                    _logger.LogWarning(
                        "Internal transfer for order {OrderId}, student {StudentId}, prefix {Prefix} found no old enrolment. Skipping.",
                        dto.ExternalId, studentId, prefix);
                    continue;
                }

                var newEnrol = new Enrolment
                {
                    StudentId = studentId,
                    OrderId = dto.OrderId,
                    CourseScheduleId = schedule.Id,
                    Status = "active",
                    TransferredFromEnrolmentId = oldEnrol.Id,
                    OriginalSku = oldEnrol.OriginalSku ?? schedule.Sku,
                    TransferReason = "CourseTransfer",
                    RefundEligible = true
                };

                var newId = await _enrolmentRepo.InsertAsync(newEnrol);

                await _enrolmentRepo.MarkTransferredAsync(oldEnrol.Id, newId);

                didAtLeastOneTransfer = true;

                _logger.LogInformation(
                    "Internal transfer completed. Old enrolment {OldId} → New enrolment {NewId}. Student {StudentId}, Order {OrderId}, Prefix {Prefix}.",
                    oldEnrol.Id, newId, studentId, dto.ExternalId, prefix);
            }

            return didAtLeastOneTransfer;
        }

        private string ExtractCoursePrefix(string sku)
        {
            if (string.IsNullOrWhiteSpace(sku)) return "";
            var parts = sku.Split('-');
            return parts.Length > 0 ? parts[0] : "";
        }

        private async Task HandleFullCancellationAsync(long orderId)
        {
            var enrolments = await _enrolmentRepo.GetByOrderIdAsync(orderId);

            foreach (var e in enrolments)
            {
                await _enrolmentRepo.CancelEnrolmentAsync(e.Id);
            }

            _logger.LogInformation(
                "Cancelled {Count} enrolments for order {OrderId}.",
                enrolments.Count(), orderId);
        }

        private async Task CreateBillingOnlyEnrolmentAsync(
            CanonicalWooOrderDto dto,
            long studentId,
            CancellationToken token)
        {
            using var doc = JsonDocument.Parse(dto.RawPayload);
            if (!doc.RootElement.TryGetProperty("line_items", out var items))
            {
                return;
            }

            foreach (var item in items.EnumerateArray())
            {
                long? productId = null;
                if (item.TryGetProperty("product_id", out var pidProp) &&
                    pidProp.TryGetInt64(out var pidVal))
                {
                    productId = pidVal;
                }

                var scheduleId = await ResolveBillingScheduleAsync(productId, item, dto);

                if (!scheduleId.HasValue)
                {
                    _logger.LogWarning(
                        "Billing only enrolment for order {OrderId} could not resolve schedule for productId {ProductId}.",
                        dto.OrderId,
                        productId);
                    continue;
                }

                var enrolment = new Enrolment
                {
                    StudentId = studentId,
                    OrderId = dto.OrderId,
                    CourseScheduleId = scheduleId.Value,
                    Status = "active"
                };

                await _enrolmentRepo.UpsertAsync(enrolment);
            }
        }

        private async Task<CourseSchedule?> ResolveScheduleAsync(CanonicalTicketDto ticket)
        {
            if (ticket.ProductId.HasValue)
            {
                var found = await _courseRepo.GetBySourceProductIdAsync(ticket.ProductId.Value);
                if (found != null)
                {
                    return found;
                }
            }

            if (!string.IsNullOrWhiteSpace(ticket.Sku))
            {
                var id = await _courseRepo.GetIdBySkuAsync(ticket.Sku);
                if (id.HasValue)
                {
                    return new CourseSchedule { Id = id.Value, Sku = ticket.Sku };
                }
            }

            var newId = await _courseRepo.UpsertFromWooPayloadAsync(
                ticket.ProductId ?? 0,
                ticket.Sku,
                null, null, null, null,
                "GBP"
            );

            return new CourseSchedule
            {
                Id = newId,
                Sku = ticket.Sku
            };
        }

        private async Task<long?> ResolveBillingScheduleAsync(
            long? productId,
            JsonElement item,
            CanonicalWooOrderDto dto)
        {
            if (productId.HasValue)
            {
                var viaProduct = await _courseRepo.GetBySourceProductIdAsync(productId.Value);
                if (viaProduct != null)
                {
                    return viaProduct.Id;
                }
            }

            if (item.TryGetProperty("sku", out var skuProp))
            {
                var sku = skuProp.GetString();
                if (!string.IsNullOrWhiteSpace(sku))
                {
                    var id = await _courseRepo.GetIdBySkuAsync(sku);
                    if (id.HasValue)
                    {
                        return id.Value;
                    }

                    return await _courseRepo.UpsertFromWooPayloadAsync(
                        productId ?? 0,
                        sku,
                        null, null, null, null,
                        "GBP"
                    );
                }
            }

            return await _courseRepo.UpsertFromWooPayloadAsync(
                productId ?? 0,
                null, null, null, null, null,
                "GBP"
            );
        }

        private string ExtractFirst(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return "";
            return name.Split(' ').FirstOrDefault() ?? "";
        }

        private string ExtractLast(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return "";
            var parts = name.Split(' ');
            return parts.Length > 1 ? string.Join(" ", parts.Skip(1)) : "";
        }

        private string MapLifecycleStatus(string status, decimal paymentTotal, decimal refundTotal)
        {
            if (status == "cancelled") return "cancelled";

            if (refundTotal >= paymentTotal && paymentTotal > 0)
            {
                return "fully_refunded";
            }

            if (refundTotal > 0)
            {
                return "partially_refunded";
            }

            return status == "completed" ? "completed" : "pending";
        }
    }
}
