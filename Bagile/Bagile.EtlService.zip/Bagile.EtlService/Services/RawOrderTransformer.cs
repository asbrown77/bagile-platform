﻿using Bagile.Domain.Repositories;
using Microsoft.Extensions.Logging;

namespace Bagile.EtlService.Services
{
    public class RawOrderTransformer
    {
        private static readonly TimeSpan BatchDelay = TimeSpan.FromSeconds(2);

        private readonly IRawOrderRepository _rawRepo;
        private readonly RawOrderRouter _router;
        private readonly ILogger<RawOrderTransformer> _logger;

        public RawOrderTransformer(
            IRawOrderRepository rawRepo,
            RawOrderRouter router,
            ILogger<RawOrderTransformer> logger)
        {
            _rawRepo = rawRepo;
            _router = router;
            _logger = logger;
        }

        public async Task ProcessPendingAsync(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                var batch = await _rawRepo.GetUnprocessedAsync(100);

                if (batch == null || !batch.Any())
                {
                    _logger.LogInformation("No unprocessed raw orders found.");
                    break;
                }

                _logger.LogInformation("Processing batch of {Count} raw orders.", batch.Count());

                foreach (var raw in batch)
                {
                    if (token.IsCancellationRequested)
                    {
                        return;
                    }

                    try
                    {
                        await _router.RouteAsync(raw, token);
                        await _rawRepo.MarkProcessedAsync(raw.Id);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Error processing raw order {RawOrderId}.", raw.Id);
                        await _rawRepo.MarkFailedAsync(raw.Id, ex.Message);
                    }
                }

                await Task.Delay(BatchDelay, token);
            }
        }
    }
}