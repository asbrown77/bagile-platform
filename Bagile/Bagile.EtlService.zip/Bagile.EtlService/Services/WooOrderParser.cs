﻿using System.Text.Json;
using Bagile.Domain.Entities;
using Bagile.EtlService.Mappers;
using Bagile.EtlService.Models;
using Bagile.Infrastructure.Clients;
using Microsoft.Extensions.Logging;

namespace Bagile.EtlService.Services
{
    public class WooOrderParser : IParser<CanonicalWooOrderDto>
    {
        private readonly ILogger<WooOrderParser> _logger;
        private readonly IFooEventsTicketsClient _fooEvents;

        public WooOrderParser(
            ILogger<WooOrderParser> logger,
            IFooEventsTicketsClient fooEvents)
        {
            _logger = logger;
            _fooEvents = fooEvents;
        }

        public async Task<CanonicalWooOrderDto> Parse(RawOrder raw)
        {
            using var doc = JsonDocument.Parse(raw.Payload);
            var root = doc.RootElement;

            // ------------------------------------------------------------
            // Basic billing fields
            // ------------------------------------------------------------
            int wooId = 0;

            if (root.TryGetProperty("id", out var idProp) &&
                idProp.TryGetInt32(out var numId))
            {
                wooId = numId;
            }

            var billing = root.GetProperty("billing");
            string billingEmail = SafeGet(billing, "email");
            string billingFirst = SafeGet(billing, "first_name");
            string billingLast = SafeGet(billing, "last_name");
            string billingCompany = SafeGet(billing, "company");

            // ------------------------------------------------------------
            // STEP 1: Build tickets from Woo line_items
            // ------------------------------------------------------------
            var baseTickets = BuildTicketsFromLineItems(
                root,
                billingFirst,
                billingLast,
                billingEmail,
                billingCompany);

            // ------------------------------------------------------------
            // STEP 2: Legacy WooCommerceEventsOrderTickets metadata
            // ------------------------------------------------------------
            bool hasLegacyMetadata = false;
            bool hasPluginMetadata = false;

            var legacyTickets = WooOrderTicketMapper.MapTickets(raw.Payload).ToList();
            if (legacyTickets.Count > 0)
            {
                hasLegacyMetadata = true;
                ApplyLegacyTicketData(baseTickets, legacyTickets, billingFirst, billingLast, billingEmail, billingCompany);
            }
            else
            {
                // --------------------------------------------------------
                // STEP 3: FooEvents API fallback
                // --------------------------------------------------------
                hasPluginMetadata = await TryApplyFooEventsPluginAsync(
                    wooId,
                    baseTickets,
                    billingFirst,
                    billingLast,
                    billingEmail,
                    billingCompany);
            }

            bool hasFooEventsMetadata = hasLegacyMetadata || hasPluginMetadata;

            // ------------------------------------------------------------
            // STEP 4: Construct the final DTO
            // ------------------------------------------------------------
            var dto = BuildOrderBaseDto(
                root,
                raw,
                wooId,
                billingEmail,
                billingFirst,
                billingLast,
                billingCompany,
                hasFooEventsMetadata);

            dto.Tickets = baseTickets;
            return dto;
        }

        // ===================================================================
        // BUILD BASE DTO
        // ===================================================================
        private CanonicalWooOrderDto BuildOrderBaseDto(
            JsonElement root,
            RawOrder raw,
            int wooId,
            string billingEmail,
            string billingFirst,
            string billingLast,
            string billingCompany,
            bool hasFooEventsMetadata)
        {
            int totalQty = 0;
            decimal subtotal = 0;
            decimal totalTax = 0;

            if (root.TryGetProperty("line_items", out var lineItems) &&
                lineItems.ValueKind == JsonValueKind.Array)
            {
                foreach (var item in lineItems.EnumerateArray())
                {
                    if (item.TryGetProperty("quantity", out var qProp) && qProp.TryGetInt32(out var q))
                        totalQty += q;

                    if (item.TryGetProperty("subtotal", out var subProp))
                        subtotal += SafeDecimal(subProp);

                    if (item.TryGetProperty("total_tax", out var taxProp))
                        totalTax += SafeDecimal(taxProp);
                }
            }

            decimal orderTotal = root.TryGetProperty("total", out var totalProp)
                ? SafeDecimal(totalProp)
                : 0m;

            decimal refundTotal = 0m;
            if (root.TryGetProperty("refunds", out var refundsProp) &&
                refundsProp.ValueKind == JsonValueKind.Array)
            {
                foreach (var refund in refundsProp.EnumerateArray())
                {
                    if (refund.TryGetProperty("total", out var rTotal))
                        refundTotal += SafeDecimal(rTotal);
                }
            }

            string currency = root.TryGetProperty("currency", out var curProp)
                ? curProp.GetString() ?? "GBP"
                : "GBP";

            return new CanonicalWooOrderDto
            {
                RawOrderId = raw.Id,
                ExternalId = wooId.ToString(),

                BillingEmail = billingEmail,
                BillingName = $"{billingFirst} {billingLast}".Trim(),
                BillingCompany = billingCompany,

                TotalQuantity = totalQty,
                SubTotal = subtotal,
                TotalTax = totalTax,
                Total = orderTotal,
                PaymentTotal = orderTotal,
                RefundTotal = refundTotal,
                Currency = currency,

                Status = root.TryGetProperty("status", out var statusProp)
                    ? statusProp.GetString() ?? "pending"
                    : "pending",

                HasFooEventsMetadata = hasFooEventsMetadata,
                RawPayload = raw.Payload,

                Tickets = new List<CanonicalTicketDto>()
            };
        }

        // ===================================================================
        // STEP 1: Build Woo line_items base tickets
        // ===================================================================
        private List<CanonicalTicketDto> BuildTicketsFromLineItems(
            JsonElement root,
            string billingFirst,
            string billingLast,
            string billingEmail,
            string billingCompany)
        {
            var result = new List<CanonicalTicketDto>();

            if (!root.TryGetProperty("line_items", out var items) ||
                items.ValueKind != JsonValueKind.Array)
            {
                return result;
            }

            foreach (var li in items.EnumerateArray())
            {
                string sku = li.TryGetProperty("sku", out var skuProp)
                    ? skuProp.GetString() ?? string.Empty
                    : string.Empty;

                long? productId = null;
                if (li.TryGetProperty("product_id", out var pidProp) &&
                    pidProp.TryGetInt64(out var pidVal))
                {
                    productId = pidVal;
                }

                int quantity = li.TryGetProperty("quantity", out var qProp) && qProp.TryGetInt32(out var q)
                    ? q : 1;

                for (int i = 0; i < quantity; i++)
                {
                    result.Add(new CanonicalTicketDto
                    {
                        Sku = sku,
                        ProductId = productId,
                        FirstName = billingFirst,
                        LastName = billingLast,
                        Email = billingEmail,
                        Company = billingCompany
                    });
                }
            }

            return result;
        }

        // ===================================================================
        // STEP 2: Apply legacy Woo Events metadata
        // ===================================================================
        private void ApplyLegacyTicketData(
            List<CanonicalTicketDto> baseTickets,
            List<WooOrderTicketMapper.TicketDto> legacyTickets,
            string billingFirst,
            string billingLast,
            string billingEmail,
            string billingCompany)
        {
            int count = Math.Min(baseTickets.Count, legacyTickets.Count);

            for (int i = 0; i < count; i++)
            {
                var legacy = legacyTickets[i];
                var ticket = baseTickets[i];

                ticket.FirstName = legacy.FirstName ?? billingFirst;
                ticket.LastName = legacy.LastName ?? billingLast;
                ticket.Email = string.IsNullOrWhiteSpace(legacy.Email) ? billingEmail : legacy.Email;
                ticket.Company = string.IsNullOrWhiteSpace(legacy.Company) ? billingCompany : legacy.Company;
            }
        }

        // ===================================================================
        // STEP 3: FooEvents plugin API fallback
        // ===================================================================
        private async Task<bool> TryApplyFooEventsPluginAsync(
            int orderId,
            List<CanonicalTicketDto> baseTickets,
            string billingFirst,
            string billingLast,
            string billingEmail,
            string billingCompany)
        {
            try
            {
                var pluginTickets = await _fooEvents.FetchTicketsForOrderAsync(orderId);

                if (pluginTickets == null || pluginTickets.Count == 0)
                {
                    return false;
                }

                int count = Math.Min(baseTickets.Count, pluginTickets.Count);

                for (int i = 0; i < count; i++)
                {
                    var ft = pluginTickets[i];
                    var ticket = baseTickets[i];

                    string full = ft.AttendeeName ?? string.Empty;

                    ticket.FirstName = SplitFirst(full) ?? billingFirst;
                    ticket.LastName = SplitLast(full) ?? billingLast;

                    ticket.Email = string.IsNullOrWhiteSpace(ft.AttendeeEmail)
                        ? billingEmail
                        : ft.AttendeeEmail;

                    ticket.Company = billingCompany;
                }

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(
                    ex,
                    "FooEvents API error for order {OrderId}, continuing with line_items only.",
                    orderId);

                return false;
            }
        }

        // ===================================================================
        // Helpers
        // ===================================================================
        private static string SplitFirst(string full)
        {
            if (string.IsNullOrWhiteSpace(full)) return string.Empty;
            var parts = full.Trim().Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
            return parts.Length > 0 ? parts[0] : string.Empty;
        }

        private static string SplitLast(string full)
        {
            if (string.IsNullOrWhiteSpace(full)) return string.Empty;
            var parts = full.Trim().Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
            return parts.Length == 2 ? parts[1] : string.Empty;
        }

        private string SafeGet(JsonElement obj, string prop)
        {
            if (obj.ValueKind != JsonValueKind.Object) return string.Empty;
            if (!obj.TryGetProperty(prop, out var val)) return string.Empty;
            return val.ValueKind == JsonValueKind.String ? val.GetString() ?? string.Empty : string.Empty;
        }

        private decimal SafeDecimal(JsonElement el)
        {
            if (el.ValueKind == JsonValueKind.Number)
                return el.GetDecimal();

            if (el.ValueKind == JsonValueKind.String &&
                decimal.TryParse(el.GetString(), out var d))
            {
                return d;
            }

            return 0m;
        }
    }
}
