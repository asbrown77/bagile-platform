﻿namespace Bagile.EtlService.Models
{
    public class CanonicalXeroInvoiceDto
    {
        public long RawOrderId { get; set; }

        // Xero invoice identifiers
        public string InvoiceId { get; set; } = "";
        public string InvoiceNumber { get; set; } = "";
        public string Reference { get; set; } = "";

        // Customer info
        public string ContactName { get; set; } = "";
        public string ContactEmail { get; set; } = "";
        public string ContactCompany { get; set; } = "";

        // Financials
        public decimal Total { get; set; }
        public decimal AmountDue { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal AmountCredited { get; set; }
        public string Currency { get; set; } = "GBP";

        // Invoice status: AUTHORISED / PAID / VOIDED / DRAFT
        public string Status { get; set; } = "";

        // Line items (courses)
        public List<CanonicalXeroLineItemDto> LineItems { get; set; } = new();

        // Raw JSON payload for debugging / enrichment
        public string RawPayload { get; set; } = "";
    }

    public class CanonicalXeroLineItemDto
    {
        public string Sku { get; set; } = "";
        public string Description { get; set; } = "";
        public int Quantity { get; set; }
        public decimal UnitAmount { get; set; }
        public decimal LineAmount { get; set; }
    }
}