﻿namespace Bagile.EtlService.Models;

public enum TransferReason
{
    Unknown,
    CourseCancelled,
    AttendeeRequested
}