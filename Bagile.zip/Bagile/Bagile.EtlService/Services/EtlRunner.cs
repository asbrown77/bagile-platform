﻿using Bagile.EtlService.Utils;
using Bagile.Infrastructure;
using Bagile.Infrastructure.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using ISourceCollector = Bagile.EtlService.Collectors.ISourceCollector;

namespace Bagile.EtlService.Services
{
    public class EtlRunner
    {
        private readonly IEnumerable<ISourceCollector> _collectors;
        private readonly IRawOrderRepository _repo;
        private readonly ILogger<EtlRunner> _logger;

        public EtlRunner(IEnumerable<ISourceCollector> collectors, IRawOrderRepository repo, ILogger<EtlRunner> logger)
        {
            _collectors = collectors;
            _repo = repo;
            _logger = logger;
        }

        public async Task RunAsync(CancellationToken ct = default)
        {
            foreach (var collector in _collectors)
            {
                var sourceName = collector.SourceName;
                _logger.LogInformation("Collecting from {Source}", sourceName);

                // find the last record for that source
                var lastCollected = await _repo.GetLastReceivedAsync(sourceName);
                _logger.LogInformation("Last collected {Source} record at {Time}", sourceName, lastCollected);

                // collect new data since that date
                var payloads = await collector.CollectAsync(lastCollected, ct);

                // insert if changed
                int insertedCount = 0;
                foreach (var raw in payloads)
                {
                    var id = JsonHelpers.ExtractId(raw);
                    await _repo.InsertIfChangedAsync(sourceName, id, raw, "etl.import");
                    insertedCount++;
                }

                _logger.LogInformation("ETL collected {Count} new {Source} records", insertedCount, sourceName);
            }
        }


    }

}
