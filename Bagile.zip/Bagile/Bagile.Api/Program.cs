﻿using Bagile.Api.Endpoints;
using Bagile.Api.Handlers;
using Bagile.Infrastructure.Repositories;
using Npgsql;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<IRawOrderRepository>(sp =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    var connStr = config.GetConnectionString("DefaultConnection")
                  ?? config.GetValue<string>("ConnectionStrings:DefaultConnection")
                  ?? config.GetValue<string>("DbConnectionString");
    return new RawOrderRepository(connStr!);
});

// Register source-specific webhook handlers
builder.Services.AddSingleton<IWebhookHandler, WooWebhookHandler>();
builder.Services.AddSingleton<IWebhookHandler, XeroWebhookHandler>();
builder.Services.AddSingleton<WebhookHandler>();

builder.Services.AddHealthChecks();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Enable Swagger in all environments
app.UseSwagger();
app.UseSwaggerUI();

// Add Kestrel binding for Azure
app.Urls.Clear();
var port = Environment.GetEnvironmentVariable("PORT") ?? "8080";
app.Urls.Add($"http://0.0.0.0:{port}");

app.Logger.LogInformation("Starting API on port {Port}", port);

app.MapGet("/", () => Results.Redirect("/swagger"));

// Add endpoints
app.MapWebhookEndpoints();
app.MapDiagnosticEndpoints();

app.Run();

public partial class Program { }