﻿namespace Bagile.Infrastructure.Models;

public record FooEventTicketDto
{
    public string TicketId { get; init; } = string.Empty;
    public string OrderId { get; init; } = string.Empty;
    public long ProductId { get; init; }
    public string Status { get; init; } = string.Empty;
    public string AttendeeEmail { get; init; } = string.Empty;
    public string? AttendeeFirstName { get; init; }
    public string? AttendeeLastName { get; init; }
    public string? AttendeeCompany { get; init; }
    public string? PurchaserEmail { get; init; }
    public string? PurchaserFirstName { get; init; }
    public string? PurchaserLastName { get; init; }
    public string? ProductSku { get; init; }

    // Transfer tracking fields
    public string? Designation { get; init; }
    public string? Comments { get; init; }
}