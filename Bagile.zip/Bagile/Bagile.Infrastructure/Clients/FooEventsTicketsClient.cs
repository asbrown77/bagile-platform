﻿using System.Net.Http.Json;
using Bagile.Infrastructure.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Bagile.Infrastructure.Clients;

public class FooEventsTicketsClient : IFooEventsTicketsClient
{
    private readonly HttpClient _http;
    private readonly ILogger<FooEventsTicketsClient> _logger;

    public FooEventsTicketsClient(
        HttpClient http,
        IConfiguration config,
        ILogger<FooEventsTicketsClient> logger)
    {
        _http = http;
        _logger = logger;

        var baseUrl = config["WordPress:BaseUrl"]
            ?? throw new InvalidOperationException("WordPress:BaseUrl not configured");
        var apiKey = config["WordPress:BagileApiKey"]
            ?? throw new InvalidOperationException("WordPress:BagileApiKey not configured");

        _http.BaseAddress = new Uri(baseUrl);
        _http.DefaultRequestHeaders.Add("X-Bagile-Key", apiKey);
    }

    public async Task<IReadOnlyList<FooEventTicketDto>> FetchTicketsForOrderAsync(
        string orderId,
        CancellationToken ct = default)
    {
        var url = $"/wp-json/bagile/v1/orders/{orderId}/tickets";
        _logger.LogInformation("Fetching FooEvents tickets for order {OrderId}", orderId);

        try
        {
            var response = await _http.GetAsync(url, ct);

            if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                _logger.LogInformation("No tickets found for order {OrderId}", orderId);
                return Array.Empty<FooEventTicketDto>();
            }

            response.EnsureSuccessStatusCode();

            var tickets = await response.Content.ReadFromJsonAsync<List<FooEventTicketDto>>(
                cancellationToken: ct);

            _logger.LogInformation("Fetched {Count} tickets for order {OrderId}",
                tickets?.Count ?? 0, orderId);

            return tickets ?? Array.Empty<FooEventTicketDto>();
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP error fetching tickets for order {OrderId}", orderId);
            return Array.Empty<FooEventTicketDto>();
        }
    }
}