﻿using System.Net.Http.Json;
using System.Text.Json;
using Bagile.Application.Common.Models;

namespace Bagile.AcceptanceTests.Drivers;

/// <summary>
/// Wrapper around HttpClient for making API requests in tests
/// </summary>
public class ApiDriver
{
    private readonly HttpClient _client;
    private HttpResponseMessage? _lastResponse;

    public ApiDriver(HttpClient client)
    {
        _client = client;
    }

    public int LastResponseStatus => (int)(_lastResponse?.StatusCode ?? 0);
    public string LastResponseContent => _lastResponse?.Content.ReadAsStringAsync().Result ?? "";

    public async Task GetOrdersAsync(
        string? status = null,
        DateTime? from = null,
        DateTime? to = null,
        string? email = null,
        int page = 1,
        int pageSize = 20)
    {
        var query = $"?page={page}&pageSize={pageSize}";
        if (status != null) query += $"&status={status}";
        if (from != null) query += $"&from={from:yyyy-MM-dd}";
        if (to != null) query += $"&to={to:yyyy-MM-dd}";
        if (email != null) query += $"&email={email}";

        _lastResponse = await _client.GetAsync($"/api/orders{query}");
    }

    public async Task GetOrderByIdAsync(long orderId)
    {
        _lastResponse = await _client.GetAsync($"/api/orders/{orderId}");
    }

    public PagedResult<T> GetLastPagedResult<T>()
    {
        if (_lastResponse == null || !_lastResponse.IsSuccessStatusCode)
            throw new InvalidOperationException("No successful response to parse");

        var json = _lastResponse.Content.ReadAsStringAsync().Result;
        return JsonSerializer.Deserialize<PagedResult<T>>(json, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        }) ?? new PagedResult<T>();
    }

    public T GetLastSingleResult<T>()
    {
        if (_lastResponse == null || !_lastResponse.IsSuccessStatusCode)
            throw new InvalidOperationException("No successful response to parse");

        return _lastResponse.Content.ReadFromJsonAsync<T>().Result
            ?? throw new InvalidOperationException("Failed to deserialize response");
    }
}