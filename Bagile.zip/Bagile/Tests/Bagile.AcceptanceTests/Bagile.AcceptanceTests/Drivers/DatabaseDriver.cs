﻿using Dapper;
using Npgsql;

namespace Bagile.AcceptanceTests.Drivers;

/// <summary>
/// Helper for setting up database test data
/// </summary>
public class DatabaseDriver
{
    private readonly string _connectionString;

    public DatabaseDriver(string connectionString)
    {
        _connectionString = connectionString;
    }

    public async Task CleanDatabaseAsync()
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        await conn.ExecuteAsync(@"
            DELETE FROM bagile.enrolments;
            DELETE FROM bagile.orders;
            DELETE FROM bagile.students;
            DELETE FROM bagile.course_schedules;
            DELETE FROM bagile.raw_orders;
        ");
    }

    public async Task<long> InsertOrderAsync(OrderTestData order)
    {
        await using var conn = new NpgsqlConnection(_connectionString);
        return await conn.ExecuteScalarAsync<long>(@"
            INSERT INTO bagile.orders (
                external_id, 
                source, 
                type, 
                status, 
                total_amount, 
                order_date, 
                contact_email, 
                billing_company
            )
            VALUES (
                @ExternalId, 
                'woo', 
                'public', 
                @Status, 
                @TotalAmount, 
                @OrderDate, 
                @CustomerEmail, 
                @CustomerCompany
            )
            RETURNING id;
        ", order);
    }

    public async Task InsertEnrolmentAsync(long orderId, EnrolmentTestData enrolment)
    {
        await using var conn = new NpgsqlConnection(_connectionString);

        // Ensure student exists
        var studentId = await conn.ExecuteScalarAsync<long>(@"
            INSERT INTO bagile.students (email, first_name, last_name)
            VALUES (@Email, 'Test', 'Student')
            ON CONFLICT (email) DO UPDATE SET email = EXCLUDED.email
            RETURNING id;
        ", new { Email = enrolment.StudentEmail });

        // Ensure course schedule exists
        var courseId = await conn.ExecuteScalarAsync<long>(@"
            INSERT INTO bagile.course_schedules (name, status, start_date, source_system, source_product_id)
            VALUES (@CourseName, 'published', NOW(), 'WooCommerce', 99999)
            ON CONFLICT (source_system, source_product_id) DO UPDATE SET name = EXCLUDED.name
            RETURNING id;
        ", new { CourseName = enrolment.CourseName });

        // Create enrolment
        await conn.ExecuteAsync(@"
            INSERT INTO bagile.enrolments (student_id, order_id, course_schedule_id)
            VALUES (@StudentId, @OrderId, @CourseId)
            ON CONFLICT (student_id, order_id, course_schedule_id) DO NOTHING;
        ", new { StudentId = studentId, OrderId = orderId, CourseId = courseId });
    }
}