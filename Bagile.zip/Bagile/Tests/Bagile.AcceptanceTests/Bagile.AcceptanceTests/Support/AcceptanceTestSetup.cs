﻿using Bagile.AcceptanceTests.Drivers;
using BoDi;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using TechTalk.SpecFlow;

namespace Bagile.AcceptanceTests.Support;

[Binding]
public class AcceptanceTestSetup
{
    private readonly IObjectContainer _container;
    private WebApplicationFactory<Program>? _factory;

    public AcceptanceTestSetup(IObjectContainer container)
    {
        _container = container;
    }

    // Runs once before any scenarios
    [BeforeTestRun]
    public static async Task BeforeTestRun()
    {
        await DatabaseFixture.EnsureInitializedAsync();
    }

    [BeforeScenario]
    public void Setup()
    {
        var connStr = DatabaseFixture.ConnectionString;
        if (string.IsNullOrWhiteSpace(connStr))
        {
            throw new InvalidOperationException(
                "DatabaseFixture was not initialised before scenario. " +
                "Check BeforeTestRun / DatabaseFixture.EnsureInitializedAsync."
            );
        }

        _factory = new WebApplicationFactory<Program>()
            .WithWebHostBuilder(builder =>
            {
                builder.ConfigureAppConfiguration((ctx, config) =>
                {
                    config.AddInMemoryCollection(new Dictionary<string, string?>
                    {
                        ["ConnectionStrings:DefaultConnection"] = connStr
                    });
                });
            });

        var client = _factory.CreateClient();

        _container.RegisterInstanceAs(new ApiDriver(client));
        _container.RegisterInstanceAs(new DatabaseDriver(connStr));
    }

    [AfterScenario]
    public void Teardown()
    {
        _factory?.Dispose();
    }

    // Optional: clean up the container DB when all tests are done
    [AfterTestRun]
    public static async Task AfterTestRun()
    {
        await DatabaseFixture.DisposeAsync();
    }
}