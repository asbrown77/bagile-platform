﻿using Bagile.Infrastructure.Clients;
using Bagile.Infrastructure.Models;
using FluentAssertions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Logging.Nulls;
using Moq;
using Moq.Protected;
using NUnit.Framework;
using System.Net;
using System.Text;

namespace Bagile.UnitTests.Clients;

[TestFixture]
public class FooEventsTicketsClientTests
{
    private Mock<HttpMessageHandler> _mockHttp;
    private IFooEventsTicketsClient _client;

    [SetUp]
    public void Setup()
    {
        var config = new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string>
            {
                ["WordPress:BaseUrl"] = "https://test.bagile.co.uk",
                ["WordPress:BagileApiKey"] = "test-key"
            })
            .Build();

        _mockHttp = new Mock<HttpMessageHandler>();
        var httpClient = new HttpClient(_mockHttp.Object);

        _client = new FooEventsTicketsClient(
            httpClient,
            config,
            NullLogger<FooEventsTicketsClient>.Instance);
    }

    [Test]
    public async Task FetchTicketsForOrderAsync_ShouldReturnTickets_WhenFound()
    {
        // Arrange
        var json = """
        [
            {
                "ticket_id": "1",
                "order_id": "12345",
                "product_id": 11492,
                "status": "Paid",
                "attendee_email": "test@example.com",
                "designation": "Transfer from cancelled PSM-061125-CB"
            }
        ]
        """;

        _mockHttp.Protected()
            .Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(json, Encoding.UTF8, "application/json")
            });

        // Act
        var tickets = await _client.FetchTicketsForOrderAsync("12345");

        // Assert
        tickets.Should().HaveCount(1);
        tickets.First().AttendeeEmail.Should().Be("test@example.com");
        tickets.First().Designation.Should().Contain("Transfer from");
    }

    [Test]
    public async Task FetchTicketsForOrderAsync_ShouldReturnEmpty_When404()
    {
        // Arrange
        _mockHttp.Protected()
            .Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.NotFound
            });

        // Act
        var tickets = await _client.FetchTicketsForOrderAsync("99999");

        // Assert
        tickets.Should().BeEmpty();
    }
}