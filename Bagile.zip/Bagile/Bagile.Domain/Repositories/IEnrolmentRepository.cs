﻿using Bagile.Domain.Entities;

public interface IEnrolmentRepository
{
    Task UpsertAsync(Enrolment enrolment);
    Task<int> CountByOrderIdAsync(long orderId);

    Task<long> InsertAsync(Enrolment enrolment);

    Task<Enrolment?> FindByOrderStudentAndSkuAsync(
        long orderId,
        long studentId,
        string sku);

    Task UpdateStatusAsync(
        long enrolmentId,
        string status,
        long? transferredToEnrolmentId = null);

    Task<IEnumerable<Enrolment>> GetByOrderIdAsync(long orderId);
}