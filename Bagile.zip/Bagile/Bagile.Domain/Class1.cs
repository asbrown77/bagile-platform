﻿namespace Bagile.Domain
{
    public class Class1
    {

    }
}
