﻿namespace Bagile.Application
{
    public class Class1
    {

    }
}
